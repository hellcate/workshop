package com.ebay.project.testcases;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.ebay.project.base.BaseTest;
import com.ebay.project.util.DataUtil;
import com.ebay.project.util.Xls_Reader;

public class EbayTest extends BaseTest {
	Xls_Reader xls;
	SoftAssert softAssert;
	String testCaseName = "EbayTest";

	@Test(dataProvider = "getData")
	public void ebayHarddiskTest(Hashtable<String, String> data) {

		test = extent.createTest(testCaseName);
		test.info(data.toString());
		if (!DataUtil.isRunnable(testCaseName, xls) || data.get("Runmode").equals("N")) {
			test.skip("Skipping the test as runmode is N");
			throw new SkipException("Skipping the test as runmode is N");
		}
		// opening Browser
		openBrowser(data.get("Browser"));
		// navigating to ebay
		navigate("appurl");
		// selecting category
		type("categoriesDropdown_xpath", data.get("Category"));
		// typing in the search term and click on search button
		type("searchTextBox_xpath", data.get("SearchTerm"));
		click("searchBtn_xpath");

		// sorting by lowest price using action class
		Actions act = new Actions(driver);
		WebElement sort = getElement("sortDropdown_xpath");
		act.moveToElement(sort).build().perform();
		WebElement lowestpriceElement = getElement("lowestpriceoptionDropdown_xpath");
		act.moveToElement(lowestpriceElement).click(lowestpriceElement).build().perform();

		click("interfaceusb3filter_xpath");
		click("storage1TBfilter_xpath");

		List<WebElement> searchResults = driver.findElements(By.xpath(prop.getProperty("searchResults_xpath")));
		test.info(searchResults.get(0).getText());
		if (!searchResults.get(0).getText().toLowerCase().contains("1tb")) {
			softAssert.assertEquals(searchResults.get(0).getText(), "1tb", "1TB is not in text of harddisk title");
		}
		softAssert.assertAll();
	}

	@BeforeMethod
	public void init() {
		softAssert = new SoftAssert();
	}

	@DataProvider
	public Object[][] getData() {
		super.init();
		xls = new Xls_Reader(System.getProperty("user.dir") + prop.getProperty("xlspath"));

		return DataUtil.getData(xls, testCaseName);

	}

	@AfterMethod
	public void quit(ITestResult result) {

		if (result.getStatus() == ITestResult.FAILURE) {
			reportFailure(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SKIP) {
			reportSkip(result.getThrowable().toString());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			reportPass("Test Passed");
		}

		extent.flush();

		if (driver != null) {
//			driver.quit();
		}
	}

}
