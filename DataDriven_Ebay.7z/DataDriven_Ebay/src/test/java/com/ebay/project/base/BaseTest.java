package com.ebay.project.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.ebay.project.util.ExtentManager;

public class BaseTest {
	public WebDriver driver;
	public Properties prop;
	public Properties envProp;
	protected ExtentTest test;
	protected static ExtentReports extent = ExtentManager.getInstance();
	boolean gridRun = false;

	public void init() {
		// init the prop file
		if (prop == null) {
			prop = new Properties();
			envProp = new Properties();
			try {
				FileInputStream fs = new FileInputStream(
						System.getProperty("user.dir") + "//src//test//resources//projectconfig.properties");
				prop.load(fs);
				String env = prop.getProperty("env");
				fs = new FileInputStream(
						System.getProperty("user.dir") + "//src//test//resources//" + env + ".properties");
				envProp.load(fs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void openBrowser(String bType) {
		test.info("Opening browser " + bType);
		if (!gridRun) {
			if (bType.equals("Mozilla"))
				driver = new FirefoxDriver();
			else if (bType.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", prop.getProperty("chromedriver_exe"));
				driver = new ChromeDriver();
			} else if (bType.equals("IE")) {
				System.setProperty("webdriver.chrome.driver", prop.getProperty("iedriver_exe"));
				driver = new InternetExplorerDriver();
			}
		} else {// grid run

			DesiredCapabilities cap = null;
			if (bType.equals("Mozilla")) {
				cap = DesiredCapabilities.firefox();
				cap.setBrowserName("firefox");
				cap.setJavascriptEnabled(true);
				cap.setPlatform(org.openqa.selenium.Platform.WINDOWS);

			} else if (bType.equals("Chrome")) {
				cap = DesiredCapabilities.chrome();
				cap.setBrowserName("chrome");
				cap.setPlatform(org.openqa.selenium.Platform.WINDOWS);
			}

			try {
				driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		test.info("Browser opened successfully " + bType);

	}

	public void navigate(String urlKey) {
		test.info("Navigating to " + envProp.getProperty(urlKey));
		driver.get(envProp.getProperty(urlKey));
	}

	public void click(String locatorKey) {
		getElement(locatorKey).click();

	}

	public void type(String locatorKey, String data) {
		getElement(locatorKey).sendKeys(data);

	}

	// finding element and returning it
	public WebElement getElement(String locatorKey) {
		WebElement e = null;
		try {
			if (locatorKey.endsWith("_id"))
				e = driver.findElement(By.id(prop.getProperty(locatorKey)));
			else if (locatorKey.endsWith("_name"))
				e = driver.findElement(By.name(prop.getProperty(locatorKey)));
			else if (locatorKey.endsWith("_xpath"))
				e = driver.findElement(By.xpath(prop.getProperty(locatorKey)));
			else {
				reportFailure("Locator not correct - " + locatorKey);
				Assert.fail("Locator not correct - " + locatorKey);
			}

		} catch (Exception ex) {
			// fail the test and report the error
			reportFailure(ex.getMessage());
			ex.printStackTrace();
			Assert.fail("Failed the test - " + ex.getMessage());
		}
		return e;
	}

	/*********************** Validations ***************************/
	public boolean verifyTitle() {
		return false;
	}

	public boolean isElementPresent(String locatorKey) {
		List<WebElement> elementList = null;
		if (locatorKey.endsWith("_id"))
			elementList = driver.findElements(By.id(prop.getProperty(locatorKey)));
		else if (locatorKey.endsWith("_name"))
			elementList = driver.findElements(By.name(prop.getProperty(locatorKey)));
		else if (locatorKey.endsWith("_xpath"))
			elementList = driver.findElements(By.xpath(prop.getProperty(locatorKey)));
		else {
			reportFailure("Locator not correct - " + locatorKey);
			Assert.fail("Locator not correct - " + locatorKey);
		}

		if (elementList.size() == 0)
			return false;
		else
			return true;
	}

	public boolean verifyText(String locatorKey, String expectedTextKey) {
		String actualText = getElement(locatorKey).getText().trim();
		String expectedText = prop.getProperty(expectedTextKey);
		if (actualText.equals(expectedText))
			return true;
		else
			return false;

	}

	public void clickAndWait(String locator_clicked, String locator_pres) {
		test.info("Clicking and waiting on - " + locator_clicked);
		int count = 5;
		for (int i = 0; i < count; i++) {
			getElement(locator_clicked).click();
			wait(2);
			if (isElementPresent(locator_pres))
				break;
		}
	}

	/***************************** Reporting ********************************/



	/**
	 * Takes a screenshot of the current webpage and adds it to {@link ExtentTest}.
	 */
	public void takeScreenShot() {
		// fileName of the screenshot
		Date d = new Date();
		String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") + ".png";
		// store screenshot in that file
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {

			org.apache.commons.io.FileUtils.copyFile(scrFile,
					new File(System.getProperty("user.dir") + "/report/screenshots/" + screenshotFile));

			// put screenshot file in reports
			test.info("ScreenShot->",
					MediaEntityBuilder.createScreenCaptureFromPath("./screenshots/" + screenshotFile).build());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void acceptAlert() {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.alertIsPresent());
		test.info("Accepting alert");
		driver.switchTo().alert().accept();
		driver.switchTo().defaultContent();
	}

	public void waitForPageToLoad() {
		wait(1);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String state = (String) js.executeScript("return document.readyState");

		while (!state.equals("complete")) {
			wait(2);
			state = (String) js.executeScript("return document.readyState");
		}
	}

	public void wait(int timeToWaitInSec) {
		try {
			Thread.sleep(timeToWaitInSec * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String getText(String locatorKey) {
		test.info("Getting text from " + locatorKey);
		return getElement(locatorKey).getText();

	}

	/**************** reproting ***************/
	/**
	 * reports fail to extent reports
	 * 
	 * @param {@link Throwable}
	 */
	public void reportFailure(Throwable t) {
		test.log(Status.FAIL, t);
		try {
			takeScreenShot();
		} catch (Exception e) {
			test.log(Status.FATAL, e);
		}
	}
	
	/**
	 * reports fail to extent reports
	 * 
	 * @param msg
	 */
	public void reportFailure(String msg) {
		test.log(Status.FAIL, msg);
		takeScreenShot();
	}
	/**
	 * reports pass to extent reports
	 * 
	 * @param msg
	 */
	public void reportPass(String msg) {
		test.log(Status.PASS, msg);
	}

	/**
	 * reports skip to extent reports
	 * 
	 * @param msg
	 */
	public void reportSkip(String msg) {
		test.skip(msg);
	}
	
	
	
}